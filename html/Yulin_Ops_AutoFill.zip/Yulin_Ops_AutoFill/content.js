// 1. 获取当前页面的完整 URL
const currentUrl = window.location.href;

let targetUser = "";
let targetPwd = "";

// 2. 匹配账号密码规则
if (currentUrl.includes(":8889")) {
    targetUser = "administrator";
    targetPwd = "YLdzzw@7766";
} else if (currentUrl.includes("/framework.php") || currentUrl.includes("/login.php")) {
    targetUser = "admin";
    targetPwd = "yldzzw@ggw.1123";
} else if (currentUrl.includes("10.127.5.4")) {
    // 华三堡垒机
    targetUser = "shiyanhong";
    targetPwd = "abcd1234";
} else if (currentUrl.includes("10.127.176.5")) {
    // 【新增】北塔运维平台
    targetUser = "shiyanhong";
    targetPwd = "shiyanhong@123";
}

// 3. 执行自动填充逻辑
if (targetUser && targetPwd) {
    // 延迟 1.5 秒执行，确保 DOM 完全渲染
    setTimeout(() => {
        // 【优化】扩大抓取范围，新增 input[name="usr"], input#username 等北塔专用特征
        const userInputs = document.querySelectorAll('input[name="user"], input[name="usr"], input#username, input[name="txt_name"], input#txt_username09, input[placeholder*="用户"], input[placeholder*="账号"]');
        
        // 【优化】扩大密码抓取范围，新增 input[name="pwd"], input#password
        const pwdInputs = document.querySelectorAll('input[type="password"], input[name="password"], input[name="pwd"], input#password');

        if (userInputs.length > 0 && pwdInputs.length > 0) {
            // 过滤隐藏元素，寻找真正可见的输入框
            const usernameField = Array.from(userInputs).find(el => el.offsetWidth > 0 && el.offsetHeight > 0) || userInputs[0];
            const passwordField = Array.from(pwdInputs).find(el => el.offsetWidth > 0 && el.offsetHeight > 0) || pwdInputs[0];

            // 绕过前端框架的数据双向绑定拦截
            const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;

            // 强行写入账号并触发事件
            if (nativeInputValueSetter) {
                nativeInputValueSetter.call(usernameField, targetUser);
            } else {
                usernameField.value = targetUser; // 兼容老式普通页面
            }
            usernameField.dispatchEvent(new Event('input', { bubbles: true }));
            usernameField.dispatchEvent(new Event('change', { bubbles: true }));

            // 强行写入密码并触发事件
            if (nativeInputValueSetter) {
                nativeInputValueSetter.call(passwordField, targetPwd);
            } else {
                passwordField.value = targetPwd;
            }
            passwordField.dispatchEvent(new Event('input', { bubbles: true }));
            passwordField.dispatchEvent(new Event('change', { bubbles: true }));
            
            console.log("🛡️ [运维助手] 账号密码已精准填充！");

            // 自动勾选用户协议复选框（如有）
            const policyCheckbox = document.querySelector('input[name="checkbox"][type="checkbox"]');
            if (policyCheckbox && !policyCheckbox.checked) {
                policyCheckbox.click();
                console.log("🛡️ [运维助手] 已自动勾选用户协议！");
            }

            // 如果有验证码，自动将光标定位到验证码输入框
            const captchaInput = document.querySelector('input[name="captcha"]');
            if (captchaInput) {
                captchaInput.focus();
                console.log("🛡️ [运维助手] 光标已聚焦到验证码输入框！");
            }
        } else {
            console.log("⚠️ [运维助手] 未找到匹配的输入框！");
        }
    }, 1500);
}